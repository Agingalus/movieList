import React from 'react';
import ReactDOM from 'react-dom';

class Go extends React.Component {

    constructor(props) {
        super(props);
        this.state = {result: 'bar'};
    }

    setFooData = (json) => {
        console.log('parsed json', json);
        this.setState(json);
    };

    elfQuery = (url, setData, event) => {
        console.log(event.target);
        fetch(url)
            .then((response) => {
                return response.json();
            })
            .then((json) => {
                setData(json);
            })
            .catch(function (ex) {
                console.log('parsing failed, URL bad, network down, or similar', ex);
            });
    };

    render() {
        return (
            <div>
                <h1>React and Jest</h1>
                <p>Hello {this.state.result}</p>
                <button id='foobar' onClick={(e) => this.elfQuery('/foo', this.setFooData, e)}>Query Foo</button>
            </div>
        );
    }
}

window.onload = function () {

    ReactDOM.render(
        <Go/>,
        document.getElementById('root')
    );
};

export default Go;
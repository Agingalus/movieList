export const testData = [
    {
        "firstName": "Lamar",
        "lastName": "Alexander",
        "street": "455 Dirksen Senate Office Building",
        "city": "Washington DC",
        "state": "TN",
        "zip": "20510",
        "phone": "202-224-4944",
        "website": "https://www.alexander.senate.gov/public",
        "email": "",
        "contact": "http://www.alexander.senate.gov/public/index.cfm?p=Email"
    },
    {
        "firstName": "Susan",
        "lastName": "Collins",
        "street": "413 Dirksen Senate Office Building",
        "city": "Washington DC",
        "state": "ME",
        "zip": "20510",
        "phone": "202-224-2523",
        "website": "https://www.collins.senate.gov",
        "email": "",
        "contact": "http://www.collins.senate.gov/contact"
    },
];


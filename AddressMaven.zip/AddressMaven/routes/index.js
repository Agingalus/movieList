var express = require('express');
var router = express.Router();
var fs = require('fs');

/* GET home page. */
router.get('/', function(req, res) {
    'use strict';
    res.render('index', {
        title: 'Elf-Express'
    });
});
router.get('/foo', (request,response)=> {
    response.send({result: "success"});
});
router.get('/worker', (request, response) => {
    response.render('worker', {
        title: request.query.title
    });
});
router.get('/get-address-list',(request,response)=>{
    let AddressData="";
    elfReadFile('routes/address-list.json')
        .then(result=> {
            AddressData = result;//result.result;
            console.log("from index.js");
            //console.log(JSON.stringify(AddressData, null, 4));
            console.log(AddressData)
            console.log(typeof(AddressData));
            response.send(JSON.parse(AddressData.result));
        });
    //response.send(AddressData.result);
    //return {result: AddressData};
});
const elfReadFile = (fileName) => {
    return new Promise(function(resolve, reject) {
        fs.readFile(fileName, 'utf8', (err, fileData) => {
            if (err) {
                reject(err);
            }
            resolve({

                result: fileData
                //JSON.parse(resultFromCallingReadfile);
                //result: fileData
                //result: {name: "Aaron"}
            });

        });
    });
};


module.exports = router;

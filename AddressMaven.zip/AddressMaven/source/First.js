import React from 'react';
class first extends React.Component {
    // IMPLEMENTATION GOES HERE
   render() {
        return (
            <div>
                <h2>First Component</h2>
                <p>The future depends on what you do today.</p>
            </div>

        )
   }
}

export default first;
import React, {Component} from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import {styles} from 'elf-styles'
import CssBaceLine from '@material-ui/core/CssBaseline'

class AddresssShow extends Component {


    render() {
        const {styles} = this.props;
        return (
            <React.Fragment>
                <div className={classes.backDiv3}>
                    <div className={classes.layout}>

                        <CssBaceLine />
                        <h1>Welcome to Elf App</h1>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}

export default withStyles(styles) (AddresssShow);

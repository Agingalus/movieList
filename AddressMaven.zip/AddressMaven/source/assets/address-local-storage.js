import {saveByIndex} from "./elf-local-storage";
import logger from "./elf-logger";

logger.off();

const KEY_SET = ['elven-store', 'elven-count'];

function setLocalStorage(addresses) {
    console.log("im in the set local stroage functin");
    //addresses = addresses.result;
    console.log('SET LOCAL', addresses);
    localStorage.setItem(KEY_SET[0], '1');
    localStorage.setItem(KEY_SET[1], addresses.length);

    addresses.forEach(function(address, index) {
        saveByIndex(address, index);
    });
    return addresses;
    //onsole.log(JSON.stringify(addresses, null, 4));
    //addresses = {name: "hi"};
    //localStorage.setItem(5,JSON.stringify(addresses, null, 4));
    //localStorage.setItem(5,JSON.stringify(addresses, null, 4))
}

function dataLoaded() {
    const elvenStore = localStorage.getItem(KEY_SET[0]);
    return (elvenStore === '1');
}

export {
    setLocalStorage,
    dataLoaded
};
import React, {Component} from 'react';

class AddresssShow extends Component {

    render() {
        return (
            <div>
                <h1>Welcome to Elf App</h1>
            </div>
        );
    }
}

export default AddresssShow;

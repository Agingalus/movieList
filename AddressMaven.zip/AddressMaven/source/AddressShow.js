import React, {Component} from 'react';
import {getByIndex, getCount} from "./assets/elf-local-storage";
import Typography from '@material-ui/core/Typography';
import { withStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
//import PropTypes from 'prop-types';
import Button from '@material-ui/core/Button';
import {styles} from './elf-styles';


// const styles = theme => ({
//     root: {
//         flexGrow: 1,
//     },
//     paper: {
//         padding: theme.spacing.unit * 5,
//         textAlign: 'center',
//         color: theme.palette.text.secondary,
//         backgroundColor: theme.palette.primary.light
//     },
//     typography: {
//         color: theme.palette.primary.dark
//     },
//     button: {
//         margin: theme.spacing.unit,
//     }
// });




class AddressShow extends Component {
    constructor() {
        super();
       let address = getByIndex(0);
        this.state = {
            index:0,
            addressInState: address  //   [{firstName: 'unknown', lastName: 'unknown', state: 'unknown'}]
        };
    }
    nextIndex =()=>{
        if (this.state.index < getCount() -1)
        {
            let newIndex = this.state.index + 1;
            this.setState( {index :newIndex});
            this.setState({ addressInState: getByIndex(newIndex)});
        }
    };
    previousIndex  =()=>{
        if (this.state.index > 0)
        {
            let newIndex = this.state.index - 1;
            this.setState( {index :newIndex});
            this.setState({ addressInState: getByIndex(newIndex)});
        }
    };
    render() {
        // const address = getByIndex(0);

        const {classes} = this.props;
        return (
            <div>
                <Paper className={classes.paper}>
                    <Typography className={classes.typography} variant="h5" gutterBottom>
                        Welcome to Elf Address
                    </Typography>
                </Paper>

                <Paper className={classes.paper}>
                    <Typography className={classes.body} variant="h5" gutterBottom>
                        First Name: {this.state.addressInState.firstName}<br/>
                        Last Name: {this.state.addressInState.lastName}<br/>
                        street: {this.state.addressInState.street}<br/>
                        city: {this.state.addressInState.city}<br/>
                        State: {this.state.addressInState.state}<br/>
                        Zip: {this.state.addressInState.zip}<br/>
                        Phone: {this.state.addressInState.phone}<br/>
                        Website: {this.state.addressInState.website}<br/>
                        Email: {this.state.addressInState.email}<br/>
                        Contact:{this.state.addressInState.contact}<br/>

                    </Typography>
                </Paper>
                <Paper className={classes.paper}>
                    <Button
                        id="getFileAction"
                        variant="contained"
                        color="primary"
                        //className={classes.button}
                        onClick={this.previousIndex}>
                        Get previous
                    </Button>
                    <Button
                        id="nextFileAction"
                        variant="contained"
                        color="primary"
                        className={classes.button}
                        onClick={this.nextIndex}>
                        Get next
                    </Button>
                </Paper>

            </div>
        );
    }
}

export default  withStyles(styles) (AddressShow);





//
// class App extends Component {


    // getFile = () => {
    //     console.log('getFile called.');
    //     this.setState({address: [{firstName: 'Patty', lastName: 'Murray', state: 'Washington'},
    //             {firstName: 'joe', lastName: 'blow', state: 'Washington'},
    //             {firstName: 'jon', lastName: 'doe', state: 'califonia'}]});
    //
    // };
    // nextIndex =()=>{
    //     if (this.state.index < this.state.address.length-1)
    //     {
    //         let newIndex = this.state.index + 1;
    //         this.setState( {index :newIndex});
    //     }
    // };
//     render() {
//         const {classes} = this.props;
//         return (
//             <div>
//                 <Paper className={classes.paper}>
//                     <Typography className={classes.typography} variant="h5" gutterBottom>
//                         Welcome to Elf Address
//                     </Typography>
//                 </Paper>
//
//                 <Paper className={classes.paper}>
//                     <Typography className={classes.body} variant="h5" gutterBottom>
//                         First Name: {this.state.address[this.state.index].firstName}<br/>
//                         Last Name: {this.state.address[this.state.index].lastName}<br/>
//                         State: {this.state.address[this.state.index].state}
//                     </Typography>
//                 </Paper>
//                 <Paper className={classes.paper}>
//                     <Button
//                         id="getFileAction"
//                         variant="contained"
//                         color="primary"
//                         //className={classes.button}
//                         onClick={this.getFile}>
//                         Get File
//                     </Button>
//                     <Button
//                         id="nextFileAction"
//                         variant="contained"
//                         color="primary"
//                         className={classes.button}
//                         onClick={this.nextIndex}>
//                         Get next
//                     </Button>
//                 </Paper>
//
//             </div>
//         );
//     }
// }
//
// export default withStyles(styles)(App);

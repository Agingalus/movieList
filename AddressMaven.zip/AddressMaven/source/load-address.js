import {setLocalStorage }from './assets/address-local-storage.js';

function loadData() {

    fetch('/get-address-list')
        .then((response) => response.json())
        .then((response) => {

            //console.log("from local Address ");
            //console.log( +JSON.stringify(response, null, 4));
            //setLocalStorage([{name: "Aaron"},{name: "Joe"}])
            setLocalStorage(response);
        })
        .catch((ex) => {
            console.log(ex);
        });
}
export {loadData};
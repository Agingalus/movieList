import React from 'react';
import ReactDOM from 'react-dom';
import Go from './control';
import Adapter from 'enzyme-adapter-react-16';
import { configure, shallow } from 'enzyme';
configure({ adapter: new Adapter() });

import ElfDebugEnzyme from '../ElfDebugEnzyme';

const elfDebugEnzyme = new ElfDebugEnzyme(true, 'App.test.js', true);


describe('Jest Create React Tests', function () {
    it('renders without crashing', () => {
        const div = document.createElement('div');
        ReactDOM.render(<Go/>, div);
        ReactDOM.unmountComponentAtNode(div);
    });
    it('renders and reads H1 text', () => {
        const wrapper = shallow(<Go />);
        console.log(wrapper.debug());
        const welcome = <h1>React and Jest</h1>;
        expect(wrapper.contains(welcome)).toEqual(true);
    });
    it('proves button click works', () => {
        const jestFunc = jest.fn();
        const wrapper = shallow(<Go />);
        wrapper.instance().elfQuery = jestFunc;
        wrapper.find('#elfQueryAction').simulate('click');
        expect(jestFunc).toHaveBeenCalledTimes(1)
    });
    it('should call setData with valid JSON causing component refresh', () => {
        const wrapper = shallow(<Go />);
        const result = <p>Hello foo test code</p>;
        wrapper.instance().setData({result: 'foo test code'});
        expect(wrapper.contains(result)).toEqual(true);
    });


});